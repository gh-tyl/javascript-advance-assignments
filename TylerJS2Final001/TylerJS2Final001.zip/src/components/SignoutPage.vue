<template>
  <h1>Signout</h1>
</template>

<script>
export default {
  name: 'SignoutPage',
  components: {
  }
}
</script>